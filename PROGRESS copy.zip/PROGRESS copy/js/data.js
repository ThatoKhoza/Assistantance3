var adrenalineRush = [
    { name: "Speed Tail", thrillRating: 9},
    { name: "BIG Splash", thrillRating: 5},
    { name: "Thunder Struck", thrillRating: 7},
    { name: "Hat Flash", thrillRating: 3},
];

var waterWorld = [
    {name: "Ride1", thrillRating: 2,},
    { name: "Ride2", thrillRating: 6,},
    { name: "Ride3", thrillRating: 4,},
    { name: "Ride4", thrillRating: 8,},
];

var kiddies = [
    {name: "Ride1", thrillRating: 4,},
    { name: "Ride2", thrillRating: 1,},
    {name: "Ride3", thrillRating: 7,},
];

var totalIncome ={Income: 6720}

