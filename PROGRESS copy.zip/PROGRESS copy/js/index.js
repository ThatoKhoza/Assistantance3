//calc sqaure km to sqaure m
console.log("hiii")

function calculateKM() {

    var calcKM = document.getElementById("squareKM").value;
    
    miles = Math.round(calcKM / 2.59)

    document.getElementById("milesValue").textContent = miles + " Square miles";

}

//calc sqaure miles to km
function calculateMiles() {

    var calcMiles = document.getElementById("squareMiles").value;
    
    kmeters = Math.round(calcMiles * 2.59);


    document.getElementById("kmValue").textContent = kmeters + " Square kilometers";

    console.log(kmeters)

}

//tickets


ticketSold = ticketSold +document.getElementById("ticketamount1").value;

function famTickets() {

    var ticketType1 = document.getElementById("ticketamount1").value;
    amount1 = Math.round(ticketType1 * 160);
    document.getElementById("ticketCost").textContent = "R" + amount1;

    document.getElementById("totaltickets").textContent =ticketSold;


}

function couplesTicket() {

    var ticketType2 = document.getElementById("ticketamount2").value;
    amount2 = Math.round(ticketType2 / 80);
    document.getElementById("ticketCost").textContent = "R" + amount2
    console.log(amount2)

}

function singleTicket(){

    var ticketType3 = document.getElementById("ticketamount3").value;
    amount3 = Math.round(ticketType3 * 40);
    document.getElementById("ticketCost").textContent = "R" + amount3 

}

function ShowRides() {

    var rides = document.getElementById("Rides").textContent = adrenalineRush[i]
    

}


     
    if (adrenalineRush[i].thrillRating <= 5)
    console.log(adrenalineRush[i])

}






