//calc sqaure km to sqaure m
console.log("hiii")


var  totalFamilyTickets=56
var totalIncome=6000;


document.getElementById("income").innerHTML= totalIncome;
document.getElementById("totaltickets").textContent= totalFamilyTickets;



function calculateKM() {

    var calcKM = document.getElementById("squareKM").value;
    
    miles = Math.round(calcKM / 2.59)

    document.getElementById("milesValue").textContent = miles + " Square miles";

}

//calc sqaure miles to km
function calculateMiles() {

    var calcMiles = document.getElementById("squareMiles").value;
    
    kmeters = Math.round(calcMiles * 2.59);


    document.getElementById("kmValue").textContent = kmeters + " Square kilometers";

    console.log(kmeters)

}

//tickets




function famTickets() {


    var ticketType1 = document.getElementById("test").value;
    amount1 = Math.round(ticketType1 * 160);
    getTotalCost(amount1)
    document.getElementById("ticketCost").textContent = "R" + amount1;
   


var fam=0;
fam= parseInt( ticketType1) + parseInt(totalFamilyTickets)
totalFamilyTickets=fam;




document.getElementById("totaltickets").textContent = totalFamilyTickets;
  
console.log(totalFamilyTickets)


}
 

function couplesTicket() {

    var ticketType2 = document.getElementById("test").value;
    console.log(ticketType2)
    amount2 = Math.round(ticketType2 * 80);
    getTotalCost(amount2)
    document.getElementById("ticketCost").textContent = "R" + amount2

    console.log(amount2)

}

function singleTicket(){

    var ticketType3 = document.getElementById("test").value;
    amount3 = Math.round(ticketType3 * 40);
    getTotalCost(amount3) 
     document.getElementById("ticketCost").textContent = "R" + amount3 

}


//



function getPrice(){
    //edit here
    let ticketType= document.getElementById("ddlViewBy");
    var strUser = ticketType.value;
    console.log(strUser)


   if(strUser=="Family"){

famTickets()

}if(strUser=="Couple (R80)")
   {
    couplesTicket()

   } if(strUser=="Single"){
       console.log("single is working")
    singleTicket();
   }

} 
function getTotalCost (amount){
var cost=0;

cost=amount+totalIncome
totalIncome=cost;


document.getElementById("income").textContent= totalIncome;



}
function headerChange(){
    let ticketType= document.getElementById("ddlViewBy");
    var textfromselect = ticketType.value;
    document.getElementById("changeheader").textContent= textfromselect;

}

  ///  if (adrenalineRush[i].thrillRating <= 5)
 //   console.log(adrenalineRush[i])

//}



/// rides page



// show rides from the option 
function showRides() {
console.log(adrenalineRush)
let rideSelect= document.getElementById("rideCategory");
var strUser = rideSelect.value;
var rideCount=0;
//<option>Select Ride</option>
//<option>Adrenaline Rush</option>
////<option>Water world</option>
//option>Kiddes rides</option>


if(strUser=="Adrenaline Rush"){

    for(var i=0;i <adrenalineRush.length;i++){


 document.getElementById("Rides").innerHTML+= "<p>"+adrenalineRush[i].name+" </p>";

    }
   document.getElementById("count").innerHTML= i;

}



// ratings ------------------------------------

if(strUser=="1-2"){

for(var i=0;i <randomRideArr.length;i++){

    if(randomRideArr[i].thrillRating<=2){

        document.getElementById("Rides").innerHTML+= "<p>"+randomRideArr[i].name+" </p>";
    }



}

    

}
if(strUser=="3-4"){
    for(var i=0;i <randomRideArr.length;i++){

        if(randomRideArr[i].thrillRating <=4 && randomRideArr[i].thrillRating >=3 ){
    
            document.getElementById("Rides").innerHTML+= "<p>"+randomRideArr[i].name+" </p>";
        }
    
    
    
    } 
}
//--------------------------------------
}

function randomRide(){
   var num =Math.floor((Math.random() * 10) + 1);



   randomRideArr[num].name;
   document.getElementById("RandomRide").textContent= randomRideArr[num].name;

}
